package org.infatlan.ms.base.dto.peticion.exposicion;

public class TempClass {

}
