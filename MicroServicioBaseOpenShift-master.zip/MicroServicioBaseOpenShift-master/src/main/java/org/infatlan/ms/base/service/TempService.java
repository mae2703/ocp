package org.infatlan.ms.base.service;

public interface TempService {

}
