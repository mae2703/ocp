package org.infatlan.ms.base.security.exception;

public class TempClass {

}
