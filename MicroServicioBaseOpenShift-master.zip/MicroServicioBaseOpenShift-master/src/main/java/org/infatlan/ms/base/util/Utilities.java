package org.infatlan.ms.base.util;

import org.springframework.stereotype.Component;

@Component
public class Utilities {

}
