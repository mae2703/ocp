package org.infatlan.ms.base.security.util;

public class TempClass {

}
