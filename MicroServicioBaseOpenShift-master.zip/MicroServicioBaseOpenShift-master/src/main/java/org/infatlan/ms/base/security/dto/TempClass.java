package org.infatlan.ms.base.security.dto;

public class TempClass {

}
