package org.infatlan.ms.base.validator;

public class TempValidator {

}
