package org.infatlan.ms.base.service.consumo;

import org.infatlan.ms.base.dto.ResultadoTodoDto;

public interface TempConsumoService {

	public ResultadoTodoDto consumoRest();
}
