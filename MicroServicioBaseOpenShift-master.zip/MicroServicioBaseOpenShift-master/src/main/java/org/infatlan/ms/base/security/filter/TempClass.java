package org.infatlan.ms.base.security.filter;

public class TempClass {

}
