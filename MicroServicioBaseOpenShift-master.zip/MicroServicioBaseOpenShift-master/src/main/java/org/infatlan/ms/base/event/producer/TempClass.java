package org.infatlan.ms.base.event.producer;

public class TempClass {

}
