package org.infatlan.ms.base.security.controller;

public class TempClass {

}
