package org.infatlan.ms.base.security.entity;

public class TempClass {

}
