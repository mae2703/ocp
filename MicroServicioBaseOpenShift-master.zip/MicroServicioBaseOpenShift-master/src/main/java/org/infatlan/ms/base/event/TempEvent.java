package org.infatlan.ms.base.event;

public class TempEvent {

}
