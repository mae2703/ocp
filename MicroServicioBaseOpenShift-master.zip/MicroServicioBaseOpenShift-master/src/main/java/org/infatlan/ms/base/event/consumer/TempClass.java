package org.infatlan.ms.base.event.consumer;

public class TempClass {

}
