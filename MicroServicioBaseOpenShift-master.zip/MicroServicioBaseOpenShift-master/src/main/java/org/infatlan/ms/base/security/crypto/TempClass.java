package org.infatlan.ms.base.security.crypto;

public class TempClass {

}
