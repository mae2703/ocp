package org.infatlan.ms.base.service.impl;

import org.infatlan.ms.base.service.TempService;

public class TempServiceImpl implements TempService{

}
