package org.infatlan.ms.base.security.util.enums;

public class TempClass {

}
