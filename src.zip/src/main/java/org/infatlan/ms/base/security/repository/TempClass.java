package org.infatlan.ms.base.security.repository;

public class TempClass {

}
