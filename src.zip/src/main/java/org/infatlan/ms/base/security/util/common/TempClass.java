package org.infatlan.ms.base.security.util.common;

public class TempClass {

}
