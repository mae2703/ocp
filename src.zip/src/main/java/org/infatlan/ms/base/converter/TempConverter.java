package org.infatlan.ms.base.converter;

import org.springframework.stereotype.Component;

@Component
public class TempConverter {

}
