package org.infatlan.ms.base.dao;

import org.springframework.stereotype.Component;

@Component
public class TempDao {

}
