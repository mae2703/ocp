package org.infatlan.ms.base.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TempController {

}
