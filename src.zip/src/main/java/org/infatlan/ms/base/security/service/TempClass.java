package org.infatlan.ms.base.security.service;

public class TempClass {

}
