package org.infatlan.ms.base.security.config;

public class TempClass {

}
