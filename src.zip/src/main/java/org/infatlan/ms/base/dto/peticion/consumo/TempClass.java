package org.infatlan.ms.base.dto.peticion.consumo;

public class TempClass {

}
