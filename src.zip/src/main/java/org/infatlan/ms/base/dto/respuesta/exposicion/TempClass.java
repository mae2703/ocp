package org.infatlan.ms.base.dto.respuesta.exposicion;

public class TempClass {

}
