package org.infatlan.ms.base.util.enums;

public class TempClass {

}
