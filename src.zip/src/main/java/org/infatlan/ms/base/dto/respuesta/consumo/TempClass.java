package org.infatlan.ms.base.dto.respuesta.consumo;

public class TempClass {

}
