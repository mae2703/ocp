package org.infatlan.ms.base.util.common;

public class TempClass {

}
